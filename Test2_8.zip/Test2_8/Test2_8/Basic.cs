﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test2_8
{
    abstract class Basic
    {
      public string _a;
      public int _x;
      public int _y;
      public int _result;
      #region 属性
      public string A
        {
            get { return _a; }
            set { _a = value; }
        }
      
        public int X
        {
            get { return _x; }
            set { _x = value; }
        }
      public int Y
        {
            get { return _y; }
            set { _y = value; }
        }
       
        public int Result
        {
            get { return _result; }
            set { _result = value; }
        }
      #endregion
        public abstract void Add();
        public abstract void Sub();
        public abstract void Mul();
        public abstract void Div();
    }
}
