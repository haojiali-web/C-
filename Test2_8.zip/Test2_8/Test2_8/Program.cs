﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test2_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Operate1 ope = new Operate1();
            Console.WriteLine("请输入1个数字");
            try
            {
                string a = Console.ReadLine();
                ope.X = Convert.ToInt32(a);
            }
            catch
            {
                Console.WriteLine("第一个数字输入错误！");
            }
            Console.WriteLine("请输入\"+\",\"-\",\"*\",\"/\"任意1种运算符");
            string choice = Console.ReadLine();
            Console.WriteLine("请再次输入1个数字：");
            try
            {
                string b = Console.ReadLine();
                ope.Y = Convert.ToInt32(b);
            }
            catch
            {
                Console.WriteLine("第二个数字输入错误！");
            }

            ope.Equals();
            switch (choice)
            {
                case "+":
                    ope.Add();
                    break;
                case "-":
                    ope.Sub();
                    break;
                case "*":
                    ope.Mul();
                    break;
                case "/":
                    ope.Div();
                    break;

                default:
                    Console.WriteLine("您输入的运算符有误！！");
                    break;
            }
        }
    }
}
