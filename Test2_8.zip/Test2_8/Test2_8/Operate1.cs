﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Test2_8
{
    class Operate1:Basic
    {
        public override void Add(){
            try
            {
                Console.WriteLine("x+y=" + (_x + _y));
                string str1 = _x.ToString();
                string str2 = _y.ToString();
                string str = str1 + str2;
                Console.WriteLine("连接两字符串：" + str); ;
              
            }
            catch
            {
                Console.WriteLine("输入错误，请重新输入！");

            }
        }
        public override void Sub()
        {
            try
            {
                Console.WriteLine("x-y=" + (_x - _y));
                string str1 = _x.ToString();
                string str2 = _y.ToString();
                string newstr = str1.Replace(str2, "");
                Console.WriteLine("删除后字符串：" + newstr); ;
       
            }
            catch
            {
                Console.WriteLine("输入错误，请重新输入！");

            }
        }
        public override void Mul()
        {
            try
            {
                Console.WriteLine("x*y=" + (_x * _y));
            }
            catch
            {
                Console.WriteLine("输入错误，请重新输入！");

            }
        }
        public override void Div()
        {
            try
            {
                Console.WriteLine("x/y=" + (_x / _y));
            }
            catch
            {
                Console.WriteLine("输入错误，请重新输入！");

            }
        }
        public void Equals()
        {
            if (_x == _y)
                Console.WriteLine("两数相等");
            else
                Console.WriteLine("两数不相等");
        }
    }
}
